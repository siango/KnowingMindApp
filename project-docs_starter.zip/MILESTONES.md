# Milestones

- Phase 0 (สัปดาห์นี้): ลิสต์/จัดหมวด n8n workflow → %: 0%
- Phase 1 (2–3 สัปดาห์): ย้าย Daily Publisher + Donation → %: 0%
- Phase 2 (30 วัน): เพิ่ม AI Orchestrator → %: 0%
- Phase 3 (60–90 วัน): Multi-tenant + SaaS → %: 0%
