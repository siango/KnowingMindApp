# Decision Journal

## [2025-09-02] Replace n8n core with Cloud Run + Workflows
- Context: n8n scale จำกัด/คุมต้นทุนยาก
- Options: (A) keep, (B) hybrid, (C) full service
- Decision: (B) Hybrid (Core → Services + Workflows; Experimental → n8n)
- Reason: เสถียร + ความเร็วทดลอง + คุมต้นทุน
- Next step: Phase 0 ลิสต์ workflow ภายใน 1 สัปดาห์
