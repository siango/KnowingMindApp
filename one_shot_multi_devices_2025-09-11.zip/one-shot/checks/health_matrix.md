| Device | Status | Note |
|---|---|---|
