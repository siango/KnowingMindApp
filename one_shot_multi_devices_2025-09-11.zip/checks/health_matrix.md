# Health Matrix

| Device  | Git | Secrets | Repo Sync | Cron/Services | Network | Dashboard |
|---------|-----|---------|-----------|---------------|---------|-----------|
| mshorse | ☐   | ☐       | ☐         | ☐             | ☐       | ☐         |

Legend: ☐ = pending, ✓ = OK, ❌ = Fail
