// Quick check for Google Cloud Storage from Node.js
// Usage:
//   npm install @google-cloud/storage
//   node scripts/storage-quickcheck.js your-bucket-name
// Notes:
//   - On local dev, authenticate with `gcloud auth application-default login`
//   - On Cloud Run, it uses the service account attached to the service

const { Storage } = require('@google-cloud/storage');
const [,, bucketNameArg] = process.argv;
if (!bucketNameArg) {
  console.error('Usage: node scripts/storage-quickcheck.js <bucket-name>');
  process.exit(1);
}

const storage = new Storage(); // ADC / default credentials

async function main() {
  const bucketName = bucketNameArg;

  // Create bucket if not exists
  const [exists] = await storage.bucket(bucketName).exists();
  if (!exists) {
    await storage.createBucket(bucketName);
    console.log(`Bucket ${bucketName} created.`);
  } else {
    console.log(`Bucket ${bucketName} already exists.`);
  }

  // Write a tiny test object
  const file = storage.bucket(bucketName).file('quickcheck.txt');
  await file.save('ok', { resumable: false });
  console.log('Wrote quickcheck.txt');

  // Read it back
  const [buf] = await file.download();
  console.log('Read quickcheck.txt ->', buf.toString('utf8'));
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
