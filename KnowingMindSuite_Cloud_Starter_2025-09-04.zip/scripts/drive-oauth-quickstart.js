// Google Drive OAuth quickstart (user-consent flow)
// Steps:
// 1) Create OAuth 2.0 Client ID (Desktop or Web) in Google Cloud Console
// 2) Put CLIENT_ID, CLIENT_SECRET in .env (or replace inline)
// 3) Run: npm install googleapis open dotenv
// 4) node scripts/drive-oauth-quickstart.js
//
// This sample lists 10 files from the user's Drive

const { google } = require('googleapis');
const open = require('open');
require('dotenv').config();

const CLIENT_ID = process.env.GDRIVE_CLIENT_ID || 'YOUR_CLIENT_ID';
const CLIENT_SECRET = process.env.GDRIVE_CLIENT_SECRET || 'YOUR_CLIENT_SECRET';
const REDIRECT_URI = process.env.GDRIVE_REDIRECT_URI || 'http://localhost:8080/oauth2callback';

const PORT = 8080;
const SCOPES = ['https://www.googleapis.com/auth/drive.readonly'];

const express = require('express');
const app = express();

async function main() {
  const oauth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
  const authUrl = oauth2Client.generateAuthUrl({ access_type: 'offline', scope: SCOPES });
  console.log('Authorize this app by visiting:', authUrl);
  await open(authUrl);

  app.get('/oauth2callback', async (req, res) => {
    const code = req.query.code;
    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);
    res.send('Authorization successful! You can close this tab.');

    const drive = google.drive({ version: 'v3', auth: oauth2Client });
    const r = await drive.files.list({ pageSize: 10, fields: 'files(id, name)' });
    console.log('Files:');
    r.data.files?.forEach(f => console.log(`- ${f.name} (${f.id})`));
    process.exit(0);
  });

  app.listen(PORT, () => console.log(`Listening on http://localhost:${PORT}`));
}

main().catch(err => { console.error(err); process.exit(1); });
