# KnowingMindSuite — Cloud Starter (2025-09-04)

รวมไฟล์ตั้งต้นที่ใช้ต่อ GCP + GitHub Actions (WIF) + Google Drive

## โครงสร้าง
- `.github/workflows/deploy-cloud-run.yml` — Workflow deploy ไป Cloud Run ผ่าน WIF
- `scripts/storage-quickcheck.js` — ทดสอบ Google Cloud Storage
- `scripts/drive-oauth-quickstart.js` — ตัวอย่าง OAuth2 เพื่อเข้าถึง Google Drive ของผู้ใช้
- `docs/drive-sa-shared-folder.md` — คู่มือแชร์โฟลเดอร์ให้ Service Account

## การใช้งานย่อ
1) ตั้งค่า WIF และ Service Account ตามโปรเจกต์จริง
2) แก้ค่า `GCP_PROJECT_ID`, `GCP_REGION` ใน workflow ให้ตรงกับของคุณ (ค่าเริ่มต้นถูกตั้งเป็น knowing-mind-app / asia-southeast1)
3) Push โค้ดขึ้น `main` หรือกด `Run workflow` แล้วเลือก service/source
4) ทดสอบ Cloud Storage:
   ```bash
   npm i @google-cloud/storage
   node scripts/storage-quickcheck.js your-bucket
   ```
5) ทดลอง Google Drive (OAuth2):
   ```bash
   npm i googleapis open dotenv express
   # ใส่ค่า CLIENT_ID/SECRET/REDIRECT ใน .env แล้วรัน
   node scripts/drive-oauth-quickstart.js
   ```
