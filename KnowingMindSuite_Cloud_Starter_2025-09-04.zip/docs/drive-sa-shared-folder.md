# Google Drive (Service Account) — แชร์โฟลเดอร์ให้งานเบื้องหลัง

กรณีงานฝั่งเซิร์ฟเวอร์/อัตโนมัติ ไม่ต้องการ flow ให้ผู้ใช้กดยินยอมบ่อยๆ ให้ใช้ **Service Account (SA)** แล้วแชร์โฟลเดอร์ใน Drive ให้ SA เข้าถึง

## ขั้นตอน
1) สร้าง Service Account ใน Google Cloud Console (IAM & Admin → Service Accounts)
2) สร้างคีย์แบบ JSON *เฉพาะกรณีจำเป็น* (แนะนำใช้ Workload Identity/WIF แทนเมื่อเป็นไปได้)
3) ใน Google Drive:
   - สร้างโฟลเดอร์ใหม่ (เช่น `Team-Shared-KnowingMind`)
   - กด `แชร์` แล้วกรอกอีเมลของ SA เช่น `my-sa@knowing-mind-app.iam.gserviceaccount.com`
   - กำหนดสิทธิ์ Viewer/Editor ตามความจำเป็น (Least privilege)
4) ในโค้ดฝั่งเซิร์ฟเวอร์ ใช้ไลบรารี `googleapis` + `google-auth-library` เพื่อเข้าถึงไฟล์ในโฟลเดอร์นั้น (ค้นหาด้วย `q` = `'FOLDER_ID' in parents`)

## ทิป
- งานไฟล์ขนาดใหญ่/สาธารณะ: พิจารณาเก็บบน **Cloud Storage** แทน แล้วส่งลิงก์แบบ Signed URL
- หลีกเลี่ยงการเก็บ key.json ใน repo; สำหรับ CI ใช้ **Workload Identity Federation (WIF)**
