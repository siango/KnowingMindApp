# Governance Policies

- PDPA/GDPR compliance
- Transparency reports
- AI Governance framework
