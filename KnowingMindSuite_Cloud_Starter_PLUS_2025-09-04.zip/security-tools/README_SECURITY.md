# Security Tools
- CHECKSUM_baseline.ps1 — สร้างไฟล์ SHA256 สำหรับทั้งโปรเจกต์
- CHECKSUM_verify.ps1 — ตรวจความเปลี่ยนแปลงเทียบกับ baseline
- BACKUP_robocopy.ps1 — สำรองไฟล์แบบ mirror (ยกเว้นโฟลเดอร์ build/cache)
- WINDOWS_UPDATE_notify_only_instructions.md — คำแนะนำตั้ง Windows Update แบบแจ้งเตือน
