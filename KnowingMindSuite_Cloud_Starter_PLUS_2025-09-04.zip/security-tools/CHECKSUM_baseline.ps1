\
    Param(
      [string]$Root = ".",
      [string]$OutFile = "CHECKSUMS_SHA256.txt"
    )
    Write-Host "== Create SHA256 baseline for $Root" -ForegroundColor Cyan
    Get-ChildItem -Path $Root -Recurse -File |
      Sort-Object FullName |
      ForEach-Object {
        $hash = Get-FileHash -Path $_.FullName -Algorithm SHA256
        "{0}  {1}" -f $hash.Hash, (Resolve-Path -Relative $_.FullName) 
      } | Set-Content -Encoding UTF8 $OutFile
    Write-Host "Wrote $OutFile" -ForegroundColor Green
