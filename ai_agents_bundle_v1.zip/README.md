﻿# AI Agents & à¸‚à¸±à¸™à¸˜à¹Œà¸«à¹‰à¸² (Samsara Pack)

à¹€à¸­à¸à¸ªà¸²à¸£à¸ªà¸–à¸²à¸›à¸±à¸•à¸¢à¹Œ AI à¹€à¸—à¸µà¸¢à¸š **à¸‚à¸±à¸™à¸˜à¹Œ 5** à¹à¸¥à¸° **à¸›à¸à¸´à¸ˆà¸ˆà¸ªà¸¡à¸¸à¸›à¸šà¸²à¸—**:
- roadmap.md â€” 1â€“3â€“6 month roadmap
- agents_table.md â€” à¸•à¸²à¸£à¸²à¸‡ 12 Agents
- agents_flow.mmd â€” Mermaid diagram
- cycle_diagram.svg â€” à¹à¸œà¸™à¸ à¸²à¸žà¸§à¸‡à¸à¸¥à¸¡
- agents_baseline_v1.md â€” baseline marker
